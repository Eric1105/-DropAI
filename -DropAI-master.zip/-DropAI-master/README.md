1. Run the predict.py file and choose mode=video or predict to reason about videos or images.
2. Need to create a logs file to put the trained model into.
3. The trained model: ep190-loss0.108-val_loss0.071.pth (https://1drv.ms/u/s!AtdnULkb8VStmQnYdWer1Bw2aI3h?e=ENmJsp)
4. The droplet multi-state dataset is shared at the following address. The images are stored in the JPEGImages folder and the label files are placed in the SegmentationClass folder. (https://1drv.ms/u/s!AtdnULkb8VStmQqiMj4I5qPgC3rN?e=0ZG8qe)
